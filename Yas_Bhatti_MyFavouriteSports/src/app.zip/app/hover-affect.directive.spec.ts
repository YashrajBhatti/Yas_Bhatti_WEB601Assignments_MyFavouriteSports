import { HoverAffectDirective } from './hover-affect.directive';

describe('HoverAffectDirective', () => {
  it('should create an instance', () => {
    const directive = new HoverAffectDirective();
    expect(directive).toBeTruthy();
  });
});
