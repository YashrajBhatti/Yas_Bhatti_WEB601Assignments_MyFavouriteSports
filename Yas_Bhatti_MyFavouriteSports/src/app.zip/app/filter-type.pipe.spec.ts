import { FilterTypePipe } from './filter-type.pipe';

describe('FilterTypePipe', () => {
  it('create an instance', () => {
    const pipe = new FilterTypePipe();
    expect(pipe).toBeTruthy();
  });
});
